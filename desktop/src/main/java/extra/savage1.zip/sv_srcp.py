#---------------------------------------------------------------------------
#           Name: sv_refs.py
#         Author: Crashday
#  Last Modified: 06/08/2012
#    Description: advancedClientList
#---------------------------------------------------------------------------

# Savage API
import core
import server
import sv_utils

#-------------------------------
# Called directly by Silverback
#-------------------------------
def advancedClientList():
    for index in sv_utils.getActiveIndices():
        core.ConsolePrint("%s�%s\n" % (str(server.GetClientInfo(int(index),INFO_NAME)),str(server.GetClientInfo(int(index),INFO_TEAM))))
